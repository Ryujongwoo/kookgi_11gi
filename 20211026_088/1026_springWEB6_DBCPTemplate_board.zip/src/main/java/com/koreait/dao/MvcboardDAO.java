package com.koreait.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.koreait.springWEB5_DBCP_board.Constant;
import com.koreait.vo.MvcboardVO;

public class MvcboardDAO {

//	DAO 클래스에서 DBCP template을 사용하기 위해서 JdbcTemplate 클래스 타입의 객체를 생성한다.
	private JdbcTemplate template;
	
	public MvcboardDAO() {
//		DAO 클래스의 객체(bean)가 생성되는 순간 servlet-context.xml 파일에서 생성되어 컨트롤러가 전달받아
//		Constant 클래스의 JdbcTemplate 클래스 타입의 객체에 저장된 bean으로 초기화시킨다.
		this.template = Constant.template;
	}
	
//	여기부터 =============================================================================================
//	DataSource dataSource;
//	
//	public MvcboardDAO() {
//		try {
//			Context context = new InitialContext();
//			dataSource = (DataSource) context.lookup("java:/comp/env/jdbc/oracle");
//		} catch (Exception e) {
//			e.printStackTrace();
//			System.out.println("연결실패!!!");
//		}
//	}
//	여기까지는 DBCP 방식에 사용할 객체를 초기화하는 부분이므로 DBCP template으로 코드 변환이 완전히 된 후
//	주석으로 처리한다. ===================================================================================
	
//	메인글 저장
//	insert, delete, update sql 명령을 실행하는 메소드의 인수로 넘어오는 데이터는 중간에 값이 변경되면 안되기
//	때문에 DBCP template에서는 메소드의 인수를 선언할 때 반드시 final을 붙여서 인수로 넘어온 데이터를 수정할
//	수 없도록 선언해야 한다.
	public void insert(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 insert() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " +
					"values (mvcboard_idx_seq.nextval, ?, ?, ?, mvcboard_idx_seq.currval, 0, 0)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvcboardVO.getName());
			pstmt.setString(2, mvcboardVO.getSubject());
			pstmt.setString(3, mvcboardVO.getContent());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " +
				"values (mvcboard_idx_seq.nextval, ?, ?, ?, mvcboard_idx_seq.currval, 0, 0)";
//		update(): 테이블의 내용이 갱신되는 sql 명령 => insert, delete, update
//		query(): 테이블의 내용이 갱신되지 않는 sql 명령 => select => 실행 결과가 여러건일 경우 사용
//		queryForObject(): 테이블의 내용이 갱신되지 않는 sql 명령 => select => 실행 결과가 1건일 경우 사용
//		queryForInt(): : 테이블의 내용이 갱신되지 않는 sql 명령 => select => 실행 결과가 정수일 경우 사용
		template.update(sql, new PreparedStatementSetter() {
//			PreparedStatementSetter 인터페이스의 익명 내장 객체를 구현하고 자동으로 Override 되는 setValues()
//			메소드에서 "?"를 채운다.
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());
				ps.setString(2, mvcboardVO.getSubject());
				ps.setString(3, mvcboardVO.getContent());
			}
		});
	}

//	전체 글 개수
	public int selectCount() {
		System.out.println("MvcboardDAO의 selectCount() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;
		try {
			conn = dataSource.getConnection();
			String sql = "select count(*) from mvcboard";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			result = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		return result;
		*/
		
		String sql = "select count(*) from mvcboard";
		return template.queryForInt(sql);
	}

//	1페이지 분량의 글
	public ArrayList<MvcboardVO> selectList(HashMap<String, Integer> hmap) {
		System.out.println("MvcboardDAO의 selectList() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<MvcboardVO> list = null;
		try {
			conn = dataSource.getConnection();
			String sql = "select * from (" + 
					     "    select rownum rnum, AA.* from (" +
					     "        select * from mvcboard order by gup desc, seq asc" +
					     "    ) AA where rownum <= ?" +
					     ") where rnum >= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hmap.get("endNo"));
			pstmt.setInt(2, hmap.get("startNo"));
			rs = pstmt.executeQuery();
			list = new ArrayList<MvcboardVO>();
			while (rs.next()) {
				AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
				MvcboardVO mvcboardVO = ctx.getBean("mvcboardVO", MvcboardVO.class);
				mvcboardVO.setIdx(rs.getInt("idx"));
				mvcboardVO.setName(rs.getString("name"));
				mvcboardVO.setSubject(rs.getString("subject"));
				mvcboardVO.setContent(rs.getString("content"));
				mvcboardVO.setGup(rs.getInt("gup"));
				mvcboardVO.setLev(rs.getInt("lev"));
				mvcboardVO.setSeq(rs.getInt("seq"));
				mvcboardVO.setHit(rs.getInt("hit"));
				mvcboardVO.setWriteDate(rs.getTimestamp("writeDate"));
				list.add(mvcboardVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		return list;
		*/
		
//		DBCP template을 사용하는 경우 select sql 명령에만 "?"를 사용할 수 없다. => "?" 자리에 데이터가 저장된
//		변수를 사용한다.
		String sql = "select * from (" + 
			     "    select rownum rnum, AA.* from (" +
			     "        select * from mvcboard order by gup desc, seq asc" +
			     "    ) AA where rownum <= " + hmap.get("endNo") + 
			     ") where rnum >= " + hmap.get("startNo");
//		select sql 명령 실행 결과를 BeanPropertyRowMapper 클래스 생성자의 인수로 MvcboardVO 클래스를 넘겨서
//		sql 명령 실행 결과를 저장시켜 리턴한다. => List 타입으로 결과가 리턴되기 때문에 메소드의 리턴 타입으로
//		형변환이 필요하다.
//		테이블의 필드 이름과 BeanPropertyRowMapper 클래스 객체의 생성자로 전달되는 클래스의 멤버 이름이 반드시
//		같아야 한다.
		return (ArrayList<MvcboardVO>) template.query(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

//	조회수 증가
	public void increment(final int idx) {
		System.out.println("MvcboardDAO의 increment() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set hit = hit + 1 where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
//		String sql = "update mvcboard set hit = hit + 1 where idx = ?";
//		template.update(sql, new PreparedStatementSetter() {
//			@Override
//			public void setValues(PreparedStatement ps) throws SQLException {
//				ps.setInt(1, idx);
//			}
//		});
		
		String sql = "update mvcboard set hit = hit + 1 where idx = " + idx;
		template.update(sql);
	}

//	글 1건
	public MvcboardVO selectByIdx(int idx) {
		System.out.println("MvcboardDAO의 selectByIdx() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MvcboardVO mvcboardVO = null;
		try {
			conn = dataSource.getConnection();
			String sql = "select * from mvcboard where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
				mvcboardVO = ctx.getBean("mvcboardVO", MvcboardVO.class);
				mvcboardVO.setIdx(rs.getInt("idx"));
				mvcboardVO.setName(rs.getString("name"));
				mvcboardVO.setSubject(rs.getString("subject"));
				mvcboardVO.setContent(rs.getString("content"));
				mvcboardVO.setGup(rs.getInt("gup"));
				mvcboardVO.setLev(rs.getInt("lev"));
				mvcboardVO.setSeq(rs.getInt("seq"));
				mvcboardVO.setHit(rs.getInt("hit"));
				mvcboardVO.setWriteDate(rs.getTimestamp("writeDate"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		return mvcboardVO;
		*/
		
		String sql = "select * from mvcboard where idx = " + idx;
		return template.queryForObject(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

//	글 수정 - 1
	public void update(final int idx, final String subject, final String content) {
		System.out.println("MvcboardDAO의 update(int idx, String subject, String content) 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, subject);
			pstmt.setString(2, content);
			pstmt.setInt(3, idx);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
//		String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
//		template.update(sql, new PreparedStatementSetter() {
//			@Override
//			public void setValues(PreparedStatement ps) throws SQLException {
//				ps.setString(1, subject);
//				ps.setString(2, content);
//				ps.setInt(3, idx);
//			}
//		});
		
		String sql = "update mvcboard set subject = '" + subject + "', content = '" + content + 
				"' where idx = " + idx;
		template.update(sql);
	}

//	글 수정 - 2
	public void update(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 update(MvcboardVO mvcboardVO) 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvcboardVO.getSubject());
			pstmt.setString(2, mvcboardVO.getContent());
			pstmt.setInt(3, mvcboardVO.getIdx());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
//		String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
//		template.update(sql, new PreparedStatementSetter() {
//			@Override
//			public void setValues(PreparedStatement ps) throws SQLException {
//				ps.setString(1, mvcboardVO.getSubject());
//				ps.setString(2, mvcboardVO.getContent());
//				ps.setInt(3, mvcboardVO.getIdx());
//			}
//		});
		
		String sql = "update mvcboard set subject = '" + mvcboardVO.getSubject() + "', content = '" + 
				mvcboardVO.getContent() + "' where idx = " + mvcboardVO.getIdx();
		template.update(sql);

	}

//	글 삭제
	public void delete(final int idx) {
		System.out.println("MvcboardDAO의 delete() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "delete from mvcboard where idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
//		String sql = "delete from mvcboard where idx = ?";
//		template.update(sql, new PreparedStatementSetter() {
//			@Override
//			public void setValues(PreparedStatement ps) throws SQLException {
//				ps.setInt(1, idx);				
//			}
//		});
		
		String sql = "delete from mvcboard where idx = " + idx;
		template.update(sql);
	}

//	조건에 만족하는 seq 1증가
	public void replyIncrement(final HashMap<String, Integer> hmap) {
		System.out.println("MvcboardDAO의 replyIncrement() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "update mvcboard set seq = seq + 1 where gup = ? and seq >= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, hmap.get("gup"));
			pstmt.setInt(2, hmap.get("seq"));
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
		String sql = "update mvcboard set seq = seq + 1 where gup = ? and seq >= ?";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, hmap.get("gup"));
				ps.setInt(2, hmap.get("seq"));
			}
		});
	}

	public void replyInsert(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 replyInsert() 메소드");
		/*
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " + 
					"values (mvcboard_idx_seq.nextval, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvcboardVO.getName());
			pstmt.setString(2, mvcboardVO.getSubject());
			pstmt.setString(3, mvcboardVO.getContent());
			pstmt.setInt(4, mvcboardVO.getGup());
			pstmt.setInt(5, mvcboardVO.getLev());
			pstmt.setInt(6, mvcboardVO.getSeq());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (conn != null) { try { conn.close(); } catch (SQLException e) { e.printStackTrace(); } }
		}
		*/
		
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " + 
				"values (mvcboard_idx_seq.nextval, ?, ?, ?, ?, ?, ?)";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());
				ps.setString(2, mvcboardVO.getSubject());
				ps.setString(3, mvcboardVO.getContent());
				ps.setInt(4, mvcboardVO.getGup());
				ps.setInt(5, mvcboardVO.getLev());
				ps.setInt(6, mvcboardVO.getSeq());
			}
		});
	}

}



















