package test;

public class Test {

	public void test() {
		System.out.println("Test 클래스의 핵심 기능");
	}
	
}
