package com.koreait.springAOP1_xml;

import org.aspectj.lang.ProceedingJoinPoint;

//	공통 기능 메소드를 모아놓은 클래스
public class LogAOP {

//	before
	public void before() {
		System.out.println("LogAOP 클래스의 before() 메소드가 실행됨");
	}
	
//	after-returning
	public void afterReturning() {
		System.out.println("LogAOP 클래스의 afterReturning() 메소드가 실행됨");
	}
	
//	after-thworing
	public void afterThrowing() {
		System.out.println("LogAOP 클래스의 afterThrowing() 메소드가 실행됨");
	}
	
//	after
	public void after() {
		System.out.println("LogAOP 클래스의 after() 메소드가 실행됨");
	}
	
//	around
//	1. around AOP 메소드는 핵심 기능이 실행되고 난 후 리턴되는 데이터 타입을 예측할 수 없으므로 반드시 리턴타입을
//	모든 데이터 타입을 포함하는 자바의 최상위 클래스인 Object로 지정해야 한다.
//	2. around AOP 메소드의 인수로 실행할 핵심 기능(메소드)이 넘어온다. => 반드시 인수로 ProceedingJoinPoint
//	인터페이스 타입의 객체를 사용한다.
//	3. around AOP 메소드는 try ~ finally 형태로 실행되며 catch는 throw Throwable로 대체된다.
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
//		핵심 기능이 실행되기 전 내용을 코딩한다.
		System.out.println("LogAOP 클래스의 around() 메소드가 실행됨 - 핵심 기능 실행 전");
//		핵심 기능이 실행되기 전 시간을 저장한다.
		long startTime = System.currentTimeMillis();
		try {
//			try 블록에서 핵심 기능을 실행한다.
			System.out.println("LogAOP 클래스의 around() 메소드가 실행됨 - 핵심 기능 실행 중");
//			ProceedingJoinPoint 인터페이스 객체로 넘어온 핵심 기능을 실행한다.
			Thread.sleep(2000);
			Object object = joinPoint.proceed();
			return object;
		} finally {
//			핵심 기능이 종료되고 난 후 실행할 내용을 코딩한다.
//			핵심 기능이 실행되과 난 후 시간을 저장한다.
			long endTime = System.currentTimeMillis();			
			System.out.println("LogAOP 클래스의 around() 메소드가 실행됨 - 핵심 기능 실행 후");
			System.out.println("핵심 기능이 실행되는데 걸린 시간: " + (endTime - startTime) / 1000. + "초");
		}
	}
	
}

















