# array : array() 함수를 사용해서 만든다.
# dim 속성을 이용해서 행, 열, 면 순서로 array 구조를 정의한다.
# dim = c(2, 3, 4) => 2행 3열짜리 matrix가 4개 있다는 의미이다.
arr1 <- array(c(1:24), dim = c(2, 3, 4))
class(arr1)

# array의 인덱싱과 슬라이싱
arr1[,,1] # array에서 1번째 면(1번째 matrix)의 데이터를 얻어온다.
arr1[1,,1] # array에서 1번째 면의 1번째 행의 데이터를 얻어온다.
arr1[,2,2] # array에서 2번째 면의 2번째 열의 데이터를 얻어온다.
arr1[1,,] # array에서 모든 면의 1번째 행 데이터를 얻어온다.
arr1[1,2,] # array에서 모든 면의 1번째 행 2번째 열의 데이터를 얻어온다.

# dataframe : data.frame() 함수를 사용해서 만든다.
data1 <- c(1, 2, 3, 4, 1, 2)
class(data1)
data2 <- c("a", "b", "c", "d", "a", "b")
class(data2)
# vector를 만들 때 문자와 숫자가 섞여있으면 모두 문자로 취급한다.
data3 <- c(1, "a", "b", 2, 3, "a")
class(data3)

# data.frame(데이터프레임으로 만들 벡터들, ...)
# 데이터프레임을 만들 때 사용한 벡터 이름이 데이터프레임의 열(변수) 이름으로
# 사용된다.
df1 <- data.frame(data1, data2, data3)
class(df1)

# 데이터프레임의 특정 열의 값을 얻어오는 방법은 2가지가 있다.
# 1. 데이터프레임이름[열번호] => 데이터프레임 형태로 데이터를 얻어온다.
#    matrix나 array에서 사용했던 인덱싱, 슬라이싱 방법을 그대로 사용할 수 있다.
df_field1 <- df1[1]
class(df_field1)
df_field2 <- df1[2:3]
class(df_field2)
df_field3 <- df1[c(1, 3)]
class(df_field3)
# 2. 데이터프레임이름$열이름 => vector 형태로 데이터를 얻어온다.
df_field4 <- df1$data1
class(df_field4) # numeric => vector
df_field5 <- df1$data2
class(df_field5) # character => vector
df_field6 <- df1$data3
class(df_field6) # character => vector

# R 4.0.0 이전에서는 데이터프레임에서 "$"를 사용해서 특정 열의 데이터를 얻어올 때
# 얻어오는 데이터가 문자 데이터일 경우 factor 타입으로 데이터를 얻어왔었다.
# factor 타입으로 얻어온 데이터를 문자 데이터로 사용하려면 as.character() 함수로
# 아래와 같이 문자 데이터로 변환시킨 후 사용했다.
# data4 <- as.character(df_field5)

# R 4.0.0 부터는 데이터프레임에서 얻어온 문자 데이터를 factor 타입으로 사용하려면
# 아래와 같이 factor() 함수를 사용해 factor 타입으로 변환시켜 사용해야 한다.
data4 <- factor(df_field5)
class(data4) # factor

# list : list() 함수를 사용해서 만든다.
v <- 1 # vector
m <- matrix(c(1:12), ncol = 6) # matrix
a <- array(c(1:20), dim = c(2, 5, 2)) # array
d <- data.frame(x1 = c(1, 2, 3), x2 = c("a", "b", "c")) # dataframe

list1 <- list(list1 = v, list2 = m, list3 = a, list4 = d)
class(list1) # list

# ===============================================================================

# 외부 데이터 읽어오기
# read.csv() : 데이터가 ","로 구분된 파일(csv 파일)을 데이터프레임 형태로
# 읽어온다.
csv_exam <- read.csv("./data/csv_exam.csv")
class(csv_exam)

csv_exam # 데이터프레임 전체를 얻어온다.
# 데이터프레임에 []만 붙여 실행하면 csv_exam를 실행한 것과 같다.
csv_exam[]

# [행,] => 행 데이터를 데이터프레임 형태로 얻어온다.
csv_exam[1,]        # 데이터프레임의 1행만 얻어온다.
class(csv_exam[1,]) # data.frame
csv_exam[1:2,]      # 데이터프레임의 1행 부터 2행까지 얻어온다.
csv_exam[c(1, 3),]  # 데이터프레임의 1행과 3행을 얻어온다.
# ","를 입력하면 데이터프레임의 행과 열을 구분해서 얻어오지만 ","를 입력하지
# 않으면 무조건 열 단위로 데이터를 얻어온다. => 데이터프레임 형태로 얻어온다.
csv_exam[3]
class(csv_exam[3]) # data.frame
csv_exam[1:3]
csv_exam[c(1, 3, 4, 5)]
csv_exam[c(1, 3:5)]
# [,열] => 열 데이터를 벡터 형태로 얻어온다.
csv_exam[,3]
class(csv_exam[,3]) # integer => vector

# 데이터프레임 이름에 "$"를 붙이고 특정 열을 얻어올 수 있다.
csv_exam$english
# [] 안에 열 이름을 쓰면 이름이 지정된 열 데이터를 데이터프렘 형태로 얻어올 수
# 있다.
csv_exam["math"]
class(csv_exam["math"]) # data.frame
csv_exam[,"english"]
class(csv_exam[,"english"]) # integer => vector
# 데이터프레임의 열 이름을 사용해서 여러개의 열을 얻어오려면 c() 함수를 사용한다.
csv_exam["math":"english"] # 에러
csv_exam[c("math", "english")]
class(csv_exam[c("math", "english")]) # data.frame
# c() 함수를 사용하면 2개 이상의 열을 얻어오기 때문에 [] 안에 ","를 찍더라도
# 데이터프레임 형태로 데이터를 얻어온다.
csv_exam[,c("math", "english")]
class(csv_exam[,c("math", "english")]) # data.frame
csv_exam[,c("math", "science")]

# 조건에 만족하는 데이터프레임의 데이터 얻어오기
# 데이터프레임[조건식]
# 데이터프레임의 class 열에 저장된 값이 1인 행 전체를 얻어온다.
# 지정한 조건에 만족하는 "행" 단위의 데이터를 얻어와야 하므로 끝에 ","를 반드시
# 붙여야 한다.
csv_exam[csv_exam$class == 1,]
# 데이터프레임의 math 열에 저장된 값이 80 이상인 행 전체를 얻어온다.
csv_exam[csv_exam$math >= 80,]
# 데이터프레임의 class 열에 저장된 값이 2이고 english 열에 저장된 데이터가 90
# 이상인 행 전체를 얻어온다.
csv_exam[csv_exam$class == 2 & csv_exam$english >= 90,] # & => and 연산자
# 데이터프레임의 math 열에 저장된 값이 30 이하이거나 science 열에 저장된 값이
# 30 이하인 행 전체를 얻어온다.
csv_exam[csv_exam$math <= 30 | csv_exam$science <= 30,] # | => or 연산자

# 읽어들여야 하는 csv 파일의 첫 줄이 열 이름이 아닐 경우 header = FALSE 옵션을
# 지정해서 읽어들이면 된다. => R이 자동으로 V1, V2, ...와 같이 열이름을 붙여준다.
# => 읽어들인 후 열 이름을 변경시켜 사용하면 된다.
csv_exam_noheader <- read.csv("./data/csv_exam_noheader.csv", header = F)
# 문자가 저장된 csv 파일을 읽어들일 때 stringsAsFactors = F 옵션을 지정하지 않으면
# 데이터를 문자가 아닌 factor 타입으로 읽어들여 처리할 때 오류가 발생될 수 있다.
# 읽어들인 데이터를 문자로 사용해야 하면 stringsAsFactors = F를 지정해야 한다.
csv_exam_noheader <- read.csv("./data/csv_exam_noheader.csv", header = F, 
                              stringsAsFactors = F)
class(csv_exam_noheader)

# 데이터프레임의 열 이름을 변경하려면 rename() 함수를 사용하면 된다.
# rename() 함수는 dplyr 패키지가 설치되고 로드되야 사용할 수 있다.
install.packages("dplyr")
library(dplyr)

# rename(데이터프레임, 새열이름 = 기존열이름, ...)
csv_exam_noheader <- rename(csv_exam_noheader, id = V1)
csv_exam_noheader <- rename(csv_exam_noheader, class = V2, math = V3, 
                            english = V4, science = V5)

# 원본 데이터를 읽었으면 망칠것에 대비해서 사본을 만들어서 작업한다.
csv_exam_copy <- csv_exam_noheader

# excel 파일을 csv 파일로 변환하지 않고 바로 읽어들이려면 readxl 패키지를 설치하고
# 로드시킨 후 사용해야 한다.
install.packages("readxl")
library(readxl)

# read_excel() 함수는 excel 파일을 tibble 타입으로 읽어온다.
excel_exam <- read_excel("./data/excel_exam.xlsx")
class(excel_exam)
# tibble 타입의 데이터는 사용하는 패키지에 따라서 정상적으로 처리되지 않을 수
# 있기 때문에 데이터프레임으로 변환시켜 사용하는 것이 좋다.
df_excel_exam <- as.data.frame(excel_exam)
class(df_excel_exam) # data.frame

# 읽어들일 excel 파일의 첫 줄이 열 이름이 아닐 경우 col_names = F 옵션을 지정해서
# 읽어들이면 된다. => 읽어들인 후 열 이름을 변경시켜 사용하면 된다.
excel_exam_noheader <- read_excel("./data/excel_exam_noheader.xlsx")
# col_names = F 옵션을 지정해서 읽어들인 excel 파일의 열 이름은 R이 자동으로
# ...1, ...2와 같이 열 이름을 붙여준다.
excel_exam_noheader <- read_excel("./data/excel_exam_noheader.xlsx", col_names = F)
# rename() 함수를 사용해서 R이 자동으로 만들어준 열 이름을 변경한다.
rename(excel_exam_noheader, id = ...1)
# R이 자동으로 붙여준 열 이름을 rename() 함수로 변경할 때 에러가 발생되면 열 이름을
# 따옴표로 묶어 실행하면 된다.
excel_exam_noheader <- rename(excel_exam_noheader, id = "...1")
excel_exam_noheader <- rename(excel_exam_noheader, class = "...2", math = "...3",
                              english = "...4", science = "...5")

# 읽어들일 excel 파일에 여러개의 sheet가 있을 때 특정 sheet의 데이터를 읽어오려면
# sheet = n(n은 읽을 sheet의 위치) 옵션을 지정해서 읽어들인다.
excel_exam_sheet3 <- read_excel("./data/excel_exam.xlsx", sheet = 3)

# ===============================================================================

# csv 파일로 저장하기
# write.csv() 함수로 데이터프레임을 csv 파일로 저장할 수 있다.
# write.csv(데이터프레임, file = "csv 파일명")
class(excel_exam)
# tibble 타입의 데이터는 데이터프레임으로 변환시킨 후 저장한다.
df_excel_exam <- as.data.frame(excel_exam)
class(df_excel_exam)
# write.csv() 함수로 csv 파일을 저장할 때 저장할 이름의 csv 파일이 열려있으면
# 파일을 여는데 실패했다는 메시지가 출력되면서 저장이 안되기 때문에 반드시
# 출력 파일이 닫혀있는 상태에서 실행해야 한다.
write.csv(df_excel_exam, file = "df_excel_exam.csv")

# ===============================================================================

# RData 파일로 저장하기
# RData 파일은 R 전용 데이터 파일로 다른 파일에 비해서 R에서 읽고 쓰는 속도가
# 빠르고 용량이 작다는 장점이 있다.
# 일반적으로 R에서 작업할 때는 RData 파일을 사용하고 R을 사용하지 않는 사람과
# 데이터를 주고 받을 경우 csv 파일이나 excel 파일을 사용한다.
# 작업중인 데이터를 R 전용 데이터 파일로 저장하고 필요할 때 불러와서 사용하면 된다.

# save() 함수로 데이터프레임을 RData 파일(*.rda)로 저장한다.
# save(데이터프레임, file = "RData 파일명")
save(df_excel_exam, file = "df_excel_exam.rda")

# rm() 함수로 사용중인 기억장소(변수)를 메모리에서 제거할 수 있다.
rm(df_excel_exam)

# load() 함수로 RData 파일에 저장된 데이터를 메모리로 가져올 수 있다.
# load(file = "RData 파일명")
load(file = "df_excel_exam.rda") # 이렇게 해야 데이터를 불러올 수 있다.
# load() 함수를 실행한 결과를 변수에 할당하면 안된다.
# 아래와 같이 load() 함수 실행 결과를 변수에 할당하면 문자 데이터로 취급된다.
# 변수에는 R 데이터가 들어가는 것이 아니고 RData 파일을 생성살 때 입력한
# 데이터프레임 이름이 저장된다.
df_excel_exam_load <- load(file = "df_excel_exam.rda") # 이렇게 하면 안된다.







