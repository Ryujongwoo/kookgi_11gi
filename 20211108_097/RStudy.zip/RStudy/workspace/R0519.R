# 변수에 데이터 할당하기
a = 100
a
b <- 200
300 -> c
print(c)

# 산술 연산자
a + b
a - b
a * b
a / b   # 나눗셈 => 결과가 실수
a %/% b # 나눗셈 => 결과가 정수
a %% b  # 나머지
a ^ 2   # 거듭 제곱

# c() 함수를 이용해서 변수에 여려개의 데이터를 저장할 수 있다.
var1 <- c(1, 3, 5, 7, 9) # 변수에 저장할 값을 ","로 구분해서 나열한다.
# class() 함수로 변수의 자료형을 얻어올 수 있다.
class(var1)
# 연속되는 값을 넣어야 할 경우 ":"을 사용해서 시작값:종료값 형식으로 입력하면
# 시작값 부터 종료값 까지 1씩 연속적으로 증가하는 데이터가 채워진다.
var2 <- c(1:100)
class(var2)
var3 <- c("짜장면", "짬뽕", "탕수육")
class(var3)
var4 <- c(1, "짜장면", 2, "짬뽕", 3, "탕수육")
class(var4)

# seq() 함수를 이용해서 변수에 여러개의 데이터를 저장할 수 있다.
# seq(시작값, 종료값[, by = 증가치]) # 증가치를 생략면 1로 취급된다.
var5 <- seq(1, 100)
var5 <- seq(1, 100, by = 1)
var6 <- seq(2, 10, by = 2)
var6 <- seq(2, 10, 2) # by를 생략하고 증가치만 입력해도 된다.

# 여러개의 데이터를 기억하는 변수에 단일 데이터를 연산하면 모든 데이터에 연산된다.
var1 + 2
# 여러개의 데이터를 기억하는 변수에 저장된 숫자를 연산하면 모든 데이터가 같은
# 위치에 있는 값끼리 연산된다.
var1 + var6

# 여러개의 데이터를 기억한 변수에 저장된 데이터를 연산할 경우 저장된 데이터의
# 개수가 같아야 정상적으로 연산된다.
# 변수에 저장된 데이터의 개수가 다를 경우 데이터 개수가 적은쪽 데이터가 처음부터
# 반복되며 연산된다.
var7 <- c(100, 200, 300, 400)
var1 + var7
var8 <- c(100, 200, 300, 400, 500, 600)
var1 + var8

# 변수에 문자를 넣을 때는 문자 앞뒤에 따옴표를 붙인다.
# 큰따옴표, 작은따옴표를 구분하지 않는다. => 짝만 맞으면 된다.
str1 <- "a"
str2 <- 'b'
str3 <- "test"
str4 <- 'sample'
str5 <- c("a", "b", "c")
str6 <- c('hello', 'world', 'is', 'good')
# 문자 데이터와 숫자 데이터를 연산할 수 없다.
str1 + 2 # Error in str1 + 2 : 이항연산자에 수치가 아닌 인수입니다.

var1
max(var1)    # 최소값
min(var1)    # 최대값
sum(var1)    # 합계
mean(var1)   # 평균
length(var1) # 변수에 저장된 데이터 개수

# 문자 데이터와 문자 데이터도 연산할 수 없다.
str1 + str2 # Error in str1 + str2 : 이항연산자에 수치가 아닌 인수입니다.

# 문자열 연결 함수
# paste(연결할 문자열[, ...][, collapse = "구분자"])

# 함수의 인수로 문자열이 저장된 변수를 나열하면 변수에 저장된 문자열을 공백으로
# 구분해서 하나로 연결해준다.
str7 <- paste(str1, str2, str3, str4)
# 함수의 인수로 변수가 나열된 경우 collapse는 무시된다.
str8 <- paste(str1, str2, str3, str4, collapse = "/")

# 함수의 인수로 문자열이 저장된 변수 1개와 collapse를 지정하면 지정된 구분자로
# 하나의 문자열로 연결한다.
str9 <- paste(str6, collapse = "/")

# 외부 패키지 사용하기
# 특정 함수를 사용하기 위해서는 그 함수가 포함된 패키지가 먼저 설치되야 한다.
# install.packages("패키지 이름") # 패키지 이름은 반드시 따옴표로 묶어준다.
install.packages("ggplot2")
# 패키지를 설치만 하면 설치된 패키지의 함수를 사용할 수 없다.
# 설치된 패키지의 함수를 사용하려면 사용할 패키지를 library() 함수를 사용해서
# 반드시 메모리에 로드시켜야 한다.
# 패키지를 로드할 때는 패키지 이름을 따옴표로 묶지 않느다.
library(ggplot2)

# 패키지 설치는 한 번만 하면 되지만 패키지를 사용하려면 R 또는 R Studio를 실행할
# 때 마다 library() 함수를 사용해서 로드해야 한다.

x <- c("a", "b", "c", "a", "c", "a")
qplot(x)

# mpg : ggplot2 패키지에서 제공되는 테스트 데이터 셋
mpg

# head() : 변수에 저장된 데이터의 앞부분을 개수를 지정해 볼 수 있다.
head(mpg)    # 데이터의 개수를 생략하면 기본값으로 6개의 데이터를 보여준다.
head(mpg, 3) # 데이터의 개수를 지정하면 지정된 개수 만큼의 데이터를 보여준다.
head(mpg, 21)

# tail() : 변수에 저장된 데이터의 뒷부분을 개수를 지정해 볼 수 있다.
tail(mpg)
tail(mpg, 3)
tail(mpg, 21)

# console은 화면 크기의 제약 때문에 일정 개수의 데이터만 보여주고 몇개의 데이터가
# 더 있다고 나오기 때문에 전체 데이터를 다 보고 싶으면 아래와 같이 View() 함수를
# 사용하면 스크립트 창 옆에 view 창이 생성되고 데이터를 볼 수 있다.
View(mpg)

qplot(data = mpg, x = hwy)
qplot(data = mpg, x = cty)
qplot(data = mpg, x = drv, y = hwy)
qplot(data = mpg, x = drv, y = hwy, geom = "line")
qplot(data = mpg, x = drv, y = hwy, geom = "boxplot")
qplot(data = mpg, x = hwy, y = cty, color = drv)
qplot(data = mpg, x = hwy, y = cty, color = class)
qplot(data = mpg, x = hwy, y = cty, color = manufacturer)

# ===============================================================================

# 변수의 종류
# 연속(양적) 변수와 범주(명목) 변수
# R의 변수는 크게 연속 변수와 범주 변수로 구분할 수 있과 변수에 저장된 값이
# 똑같은 숫자라 하더라도 변수의 종류가 무엇인강 따라 사용하는 분석 방법이
# 달라진다.

# 연속 변수
# 연속 변수는 키, 몸무게, 소득 등과 같이 연속적이고 크기를 의미하는 데이터로
# 구성된 변수를 의미하며 데이터가 크기를 가지기 때문에 덧셈, 뺄셈 등의 산술 
# 연산이 가능하다.

var9 <- c(1, 2, 3, 1, 2)
class(var9)
var9 + 2 # 연속 변수는 산술 연산이 가능하다.
mean(var9)

# 범주 변수 => factor
# 범주 변수는 데이터가 크기를 가지지 않고 대상의 분류하는 의미를 가지는 변수로
# 성별과 같이 남자는 1, 여자는 2로 각각의 범주를 분류한다.
# 변수에 저장된 데이터가 크기를 의미하지 않기 때문에 합계나 평균을 계산하는
# 산술 연산이 불가능하다.

# factor() 함수를 사용해서 범주 변수를 만든다.
var10 <- factor(c(1, 2, 3, 1, 2))
class(var10)
var10 + 2 # 요인(factors)에 대하여 의미있는 ‘+’가 아닙니다.
mean(var10) # 인자가 수치형 또는 논리형이 아니므로 NA를 반환합니다
# levels() 함수를 사용하면 범주 변수의 범주 목록(Levels)만 얻어올 수 있다.
levels(var10)

# 범주 변수는 크기를 의미하는 것이 아니기 때문에 문자 데이터로 구성되는 변수도
# 가능하다.
str10 <- c("짜장", "짬뽕", "짜장", "만두","짜장", "기스면")
class(str10)
str11 <- factor(c("짜장", "짬뽕", "짜장", "만두","짜장", "기스면"))
class(str11)
levels(str11) # 범주 변수의 범주 목록은 오름차순(가나다순)으로 정렬된다.

# 데이터 형 변환 함수
# as.numeric() : 데이터를 numeric(숫자) 타입으로 변환한다.
# as.factor() : 데이터를 factor(범주) 타입으로 변환한다.
# as.character() : 데이터를 character(문자) 타입으로 변환한다.
# as.Date() : 데이터를 Date(날짜) 타입으로 변환한다.
# as.data.frame() : 데이터를 dataframe 타입으로 변환한다.

class(var10) # 범주 변수
var11 <- as.numeric(var10)
class(var11) # 연속 변수
levels(var11) # 연속 변수는 범주가 없기 때문에 NULL이 출력된다.

# ===============================================================================

# 데이터 구조
# vector => 1차원, 1가지 데이터 타입으로 구성된다.
# matrix => 2차원, 1가지 데이터 타입으로 구성된다.
# dataframe => 2차원, 2가지 이상의 데이터 타입으로 구성된다.
# array => 다차원, matrix로 구성된다. matrix가 여러개 있는 구조이다.
# list => 다차원, vector, matrix, dataframe, array가 여러개 있는 구조이다.

var12 <- c(1:12) # vector
var13 <- seq(1, 12, by = 1) # vector

# matrix : matrix() 함수를 사용해서 만든다.
# vector var12에 저장된 데이를 이용해서 matrix를 만든다. 
# matrix의 행과 열을 지정하지 않았기 때문에 12행 1열인 matrix가 만들어진다.
mat1 <- matrix(var12)
# nrow 옵션으로 행의 개수를 지정하고 ncol 옵션으로 열의 개수를 지정한다.
mat2 <- matrix(var12, nrow = 4, ncol = 3)
# nrow 옵션만 지정해도 ncol을 자동으로 계산해서 matrix가 만들어진다.
mat3 <- matrix(var12, nrow = 4)
# ncol 옵션만 지정해도 nrow를 자동으로 계산해서 matrix가 만들어진다.
mat4 <- matrix(var12, ncol = 4)

# 행과 열의 개수 보다 데이터의 개수가 적으면 데이터가 처음부터 반복된다.
mat5 <- matrix(var12, nrow = 4, ncol = 4)
# 행과 열의 개수 보다 데이터의 개수가 많으면 남는 데이터는 무시된다.
mat6 <- matrix(var12, nrow = 3, ncol = 3)

# matrix에 데이터가 채워지는 방향은 열 방향을 우선해서 채워지지만 byrow 옵션을
# TRUE로 지정하면 행 방향을 우선해서 데이터를 채울 수 있다.
# R은 논리값을 의미하는 TRUE와 FALSE를 반드시 대문자로 사용해야 한다.
# TRUE와 FALSE 대신 T와 F로도 사용할 수 있다.
mat7 <- matrix(var12, nrow = 4, ncol = 3, byrow = T)

# matrix 인덱싱 => matrix의 일부를 얻어온다. => 특정 위치, 행, 열
mat7
mat7[7]   # 지정된 위치의 데이터 한 개를 얻어온다. => 열 우선 방식
mat7[1,]  # 지정된 위치의 행 데이터 전체를 얻어온다.
mat7[,1]  # 지정된 위치의 열 데이터 전체를 얻어온다.
mat7[3,2] # 지정된 행, 열 위치의 데이터를 얻어온다.

# matrix 슬라이싱 => matrix의 일부를 얻어온다. => 얻어올 범위를 지정한다.
# 범위를 지정하는 방식은 ":"을 사용하면 붙어있는 범위를 지정할 수 있고 c() 함수를
# 사용하면 떨어져있는 데이터의 범위를 지정할 수 있다.
mat7[2:3,] # 지정된 범위의 행 데이터를 얻어온다.
mat7[,2:3] # 지정된 범위의 열 데이터를 얻어온다.
mat7[c(1, 3),] # c() 함수로 지정된 위치의 행 데이터를 얻어온다.
mat7[,c(1, 3)] # c() 함수로 지정된 위치의 열 데이터를 얻어온다.

# matrix에서 얻어올 데이터의 위치를 지정할 때 앞에 "-"를 붙여주면 "-"가 붙어있는
# 데이터를 제외한 나머지 데이터만 얻어온다.
mat7[-1,] # "-"를 붙여준 행을 제외한 나머지 행 데이터를 얻어온다.
mat7[,-1] # "-"를 붙여준 열을 제외한 나머지 행 데이터를 얻어온다.
mat7[-(1:2),]   # "-"를 붙여준 범위의 행을 제외한 나머지 행 데이터를 얻어온다.
mat7[-c(1, 2),]
mat7[,-c(2, 4)] # "-"를 붙여준 범위의 열을 제외한 나머지 열 데이터를 얻어온다.

# ===============================================================================

# 기본 패키지를 제외한 모든 사용자 설치 패키지를 제거한다.
# create a list of all installed packages
ip <- as.data.frame(installed.packages())
head(ip)
# if you use MRO, make sure that no packages in this library will be removed
ip <- subset(ip, !grepl("MRO", ip$LibPath))
# we don't want to remove base or recommended packages either\
ip <- ip[!(ip[,"Priority"] %in% c("base", "recommended")),]
# determine the library where the packages are installed
path.lib <- unique(ip$LibPath)
# create a vector with all the names of the packages you want to remove
pkgs.to.remove <- ip[,1]
head(pkgs.to.remove)
# remove the packages
sapply(pkgs.to.remove, remove.packages, lib = path.lib)