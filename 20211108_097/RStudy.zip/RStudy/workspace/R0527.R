library(foreign)
raw_welfare <- read.spss("./data/Koweps_hpc10_2015_beta1.sav", to.data.frame = T)
welfare <- raw_welfare # 사본을 만든다.
library(dplyr)
# 코드표를 참조해서 열 이름을 변경한다.
welfare <- rename(welfare, gender = h10_g3)        # 성별
welfare <- rename(welfare, birth = h10_g4)         # 태어난 연도
welfare <- rename(welfare, marriage = h10_g10)     # 혼인상태
welfare <- rename(welfare, religion = h10_g11)     # 종교
welfare <- rename(welfare, code_job = h10_eco9)    # 직종코드
welfare <- rename(welfare, income = p1002_8aq1)    # 급여
welfare <- rename(welfare, code_region = h10_reg7) # 지역코드
# 성별 전처리
welfare$gender <- ifelse(welfare$gender == 9, NA, welfare$gender)
welfare$gender <- ifelse(welfare$gender == 1, "male", "female")
# 급여 전처리
welfare$income <- ifelse(welfare$income < 1 | welfare$income > 9998, NA,
                         welfare$income)
# 태어난 년도 전처리
welfare$birth <- ifelse(welfare$birth == 9999, NA, welfare$birth)
welfare$birth <- ifelse(welfare$birth < 1900 | welfare$birth > 2014, NA,
                        welfare$birth)
# 파생 변수를 만들어 나이 저장
welfare$age <- 2015 - welfare$birth
# 파생 변수를 만들어 연령대 저장
welfare <- welfare %>% 
  mutate(
    age_group = ifelse(age < 30, "young", ifelse(age < 60, "middle", "old"))
  )
# 코드북(Koweps_Codebook.xlsx) 파일의 2번째 시트의 데이터르 읽어온다.
library(readxl)
job_list <- read_excel("./data/Koweps_Codebook.xlsx", sheet = 2)
welfare_job <- welfare
welfare_job <- left_join(welfare_job, job_list, by = "code_job")
# 종교 전처리
welfare$religion <- ifelse(welfare$religion %in% c(1, 2), welfare$religion, NA)
welfare$religion <- ifelse(welfare$religion == 1, "yes", "no")
# 혼인상태 전처리
welfare$marriage <- ifelse(welfare$marriage == 9, NA, welfare$marriage)
welfare$group_marriage <- ifelse(welfare$marriage %in% c(1, 4), "marriage",
                                 ifelse(welfare$marriage == 3, "divorce", NA))
library(ggplot2)

# ===============================================================================

# 연령대별 이혼율 분석

# 연령대별 이혼율 표를 만든다.
age_group_marriage <- welfare %>% 
  filter(!is.na(group_marriage)) %>% 
  group_by(age_group, group_marriage) %>% 
  summarise(n = n()) %>% 
  mutate(pct = round(n / sum(n) * 100, 1))

ggplot(data = age_group_marriage, 
       aes(x = age_group, y = n, fill = group_marriage)) +
  geom_col(position = "dodge") + 
  scale_x_discrete(limit = c("young", "middle", "old"))

ggplot(data = age_group_marriage, 
       aes(x = group_marriage, y = n, fill = age_group)) +
  geom_col(position = "dodge") + 
  scale_x_discrete(limit = c("marriage", "divorce"))

# ===============================================================================

# 지역 전처리
table(welfare$code_region)
welfare_region <- welfare
welfare_region$code_region <- ifelse(welfare_region$code_region < 1 |
                                       welfare_region$code_region > 7,
                                     NA, welfare_region$code_region)
table(welfare_region$code_region)

# 7개의 지역을 기억하는 데이터프레임을 만든다.
list_region <- data.frame(code_region = c(1:7),
                          region = c('서울', '수도권(인천/경기)', '부산/경남/울산', 
                                     '대구/경북', '대전/충남', '강원/충북', 
                                     '광주/전남/전북/제주도'))

# welfare_region와 list_region를 left_join() 함수로 code_region 변수를 기준으로
# 결합시킨다.
welfare_region <- left_join(welfare_region, list_region, by = 'code_region')
welfare_region %>% 
  select(code_region, region)
table(welfare_region$region)

# ===============================================================================

# 어떤 지역에 어떤 연령대가 많이 사는가?

# 지역별, 연령대별 비율표를 만든다
region_age_group <- welfare_region %>% 
  filter(!is.na(region)) %>% 
  group_by(region, age_group) %>% 
  summarise(n = n()) %>% 
  mutate(pct = round(n / sum(n) * 100, 1))

ggplot(data = region_age_group, aes(x = region, y = pct, fill = age_group)) +
  geom_col(position = "dodge") +
  coord_flip()

# ggplot() 함수에서 data 옵션 aes() 함수에서 x, y 옵션을 생략해도 자동으로 인식
# 한다.
ggplot(region_age_group, aes(region, pct, fill = age_group)) +
  geom_col(position = "dodge") +
  coord_flip()

# 연령대가 young인 사람들이 많이 사는 지역은 어디일까?
region_age_group_young <- region_age_group %>% 
  filter(age_group == "young")

ggplot(region_age_group_young, aes(reorder(region, pct), pct)) +
  geom_col(position = "dodge") +
  coord_flip()

ggplot(region_age_group_young, aes(reorder(region, -pct), pct)) +
  geom_col(position = "dodge") +
  coord_flip()

region_age_group_young <- region_age_group %>% 
  filter(age_group == "young") %>% 
  arrange(pct)
# x축 레이블 출력 순서를 별도로 저장한다.
order_young_list <- region_age_group_young$region

ggplot(region_age_group_young, aes(region, pct)) +
  geom_col(position = "dodge") +
  coord_flip() +
  scale_x_discrete(limit = order_young_list)

# 연령대가 middle인 사람들이 많이 사는 지역은 어디일까?
region_age_group_middle <- region_age_group %>% 
  filter(age_group == "middle") %>% 
  arrange(pct)

ggplot(region_age_group_middle, aes(reorder(region, pct), pct)) +
  geom_col(position = "dodge") +
  coord_flip() + 
  xlab("지역") +
  ylab("비율")

order_middle_list <- region_age_group_middle$region
ggplot(region_age_group_middle, aes(region, pct)) +
  geom_col(position = "dodge") +
  coord_flip() + xlab("지역") + ylab("비율") +
  scale_x_discrete(limit = order_middle_list)

# 연령대가 old인 사람들이 많이 사는 지역은 어디일까?
region_age_group_old <- region_age_group %>% 
  filter(age_group == "old") %>% 
  arrange(pct)

ggplot(region_age_group_old, aes(reorder(region, pct), pct)) +
  geom_col(position = "dodge") +
  coord_flip() + 
  xlab("지역") +
  ylab("비율")

order_old_list <- region_age_group_old$region
ggplot(region_age_group_old, aes(region, pct)) +
  geom_col(position = "dodge") +
  coord_flip() + xlab("지역") + ylab("비율") +
  scale_x_discrete(limit = order_old_list)

# ===============================================================================

order_young_list <- region_age_group_young$region
order_middle_list <- region_age_group_middle$region
order_old_list <- region_age_group_old$region

ggplot(region_age_group, aes(region, pct, fill = age_group)) +
  geom_col(position = "dodge") +
  coord_flip() +
  scale_x_discrete(limit = order_young_list)

ggplot(region_age_group, aes(region, pct, fill = age_group)) +
  geom_col(position = "dodge") +
  coord_flip() +
  scale_x_discrete(limit = order_middle_list)

ggplot(region_age_group, aes(region, pct, fill = age_group)) +
  geom_col(position = "dodge") +
  coord_flip() +
  scale_x_discrete(limit = order_old_list)

# ===============================================================================

# 범례 순서 변경하기

# aes() 함수의 fill 속성에 지정할 변수를 factor() 함수를 실행해서 vector 타입을
# factor 타입으로 변경할 때 levels 속성으로 출력할 범례 순서를 지정하면 된다.

class(region_age_group$age_group) # character => vector
# age_group은 factor가 아니기 때문에 levels() 함수를 실행하면 NULL이 출력된다.
levels(region_age_group$age_group) # NULL
# factor() 함수를 사용해서 age_group 변수 타입을 factor로 변환하고 levels 속성으로
# 범례 순서를 변경할 수 있다.

# factor() 함수만 사용하면 범주 순서가 문자열의 오름차순으로 설정된다.
region_age_group$age_group <- factor(region_age_group$age_group)
levels(region_age_group$age_group) # middle => old => young
# factor() 함수의 levels 옵션으로 범주 순서를 지정할 수 있다.
region_age_group$age_group <- factor(region_age_group$age_group,
                                     levels = c("young", "middle", "old"))
levels(region_age_group$age_group) # young => middle => old

ggplot(region_age_group, aes(region, pct, fill = age_group)) +
  geom_col(position = "dodge") +
  coord_flip() +
  scale_x_discrete(limit = order_young_list)

# ===============================================================================

# 텍스트 마이닝
# 텍스트 마이닝이란 문자로 된 데이터에서 가치있는 정보를 얻어내서 분석하는 기법을
# 말한다.
# 텍스트 마이닝을 할 때 가장 먼저 하는 작업은 분석하려는 텍스트가 저장된 웹
# 페이지의 텍스트를 얻어오는 것이다. => 크롤링, 스크레이핑
# 준비된 데이터의 문장을 구성하는 어절들이 어떤 품사로 되어있는지 파악하는 형태소
# 분석 작업을 해야하고 형태소 분석이란 어절들의 품사를 파악한 후 명사, 형용사,
# 동사 등 의미를 가진 품사의 단어를 추출해 각 단어가 얼마나 등장했는가 파악하는
# 것이다.

# 1. 자바가 컴퓨터에 설치되어 있어야 하고 아래의 패키지를 설치하고 로드한다.
install.packages("rJava")
library(rJava)
install.packages("digest")
library(digest)
install.packages("rlang")
library(rlang)
install.packages("KoNLP")
library(KoNLP)

# R이 4.0.0 버전으로 업데이트 되면서 2020년 5월 27일 현재 install.packages() 함수로
# KoNLP 패키지가 설치되지 않는다.

# 아래의 다운로드 경로에서 rtools를 다운받아 설치한다.
# 다운로드 경로 : https://cran.r-project.org/bin/windows/Rtools/index.html
# 설치가 완료되면 환경 변수를 편집한다. => 한글 파일 참조
# 설치시 다른 패키지와 충돌이 발생될 수 있으므로 R0519.R 파일의 240번 줄부터
# 끝까지 스크립트를 실행해 기본 패키지를 제외한 모든 설치한 패키지를 제거한다.

# java, rJava 설치
install.packages("multilinguer")
library(multilinguer)
install_jdk()

# 의존성 패키지 설치
install.packages(c("stringr", "hash", "tau", "Sejong", "RSQLite", "devtools"),
                 type = "binary")
# github 버전 설치
install.packages("remotes")
remotes::install_github('haven-jeon/KoNLP', upgrade = "never", 
                        INSTALL_opts=c("--no-multiarch"))

library("KoNLP")

# 2. 데이터 전처리에 사용할 패키지를 로드하고 사용할 형태소 사전을 설정한다.
install.packages("dplyr")
library(dplyr)
useSystemDic()
useSejongDic()
useNIADic()

# extractNoun() 함수를 사용해 명사를 추출한다. => 결과가 vector로 리턴된다.
noun <- extractNoun("대한민국의 영토는 한반도와 그 부속 도서로 한다.")
class(noun)
# class(noun) 함수를 실행했을 때 결과가 list라고 나오면 아래와 같이 unlist() 함수를
# 이용해서 vector 형태로 변환 후 작업을 해야한다.
# noun <- unlist(noun)

# 3. 형태소 분석 작업을 실행할 데이터를 읽어들인다.
# readLines() 함수로 텍스트 마이닝을 실행할 데이터가 저장된 텍스트 파일을 읽는다.
txt <- readLines("./data/hiphop.txt")
class(txt)

# 정규식 => https://highcode.tistory.com/6 참조
# ^ : 문자열의 시작
# $ : 문자열의 종료
# . : 임의의 한 문자 (문자의 종류 가리지 않음) 단, \ 는 넣을 수 없음
# * : 앞 문자가 없을 수도 무한정 많을 수도 있음
# + : 앞 문자가 하나 이상
# ? : 앞 문자가 없거나 하나있음
# [] : 문자의 집합이나 범위를 나타내며 두 문자 사이는 - 기호로 범위를 나타낸다.
#      []내에서 ^가 선행하여 존재하면 not 을 나타낸다.
# {} : 횟수 또는 범위를 나타낸다.
# () : 소괄호 안의 문자를 하나의 문자로 인식 
# | : 패턴 안에서 or 연산을 수행할 때 사용
# \s : 공백 문자
# \S : 공백 문자가 아닌 나머지 문자
# \w : 알파벳이나 숫자
# \W : 알파벳이나 숫자를 제외한 문자
# \d : 숫자 [0-9]와 동일
# \D : 숫자를 제외한 모든 문자
# \ : 정규표현식 역슬래시(\)는 확장 문자
#     역슬래시 다음에 일반 문자가 오면 특수문자로 취급하고 역슬래시 다음에
#     특수문자가 오면 그 문자 자체를 의미
# (?i) : 앞 부분에 (?i) 라는 옵션을 넣어주면 대소문자를 구분하지 않음

# 자주 쓰이는 패턴
# 숫자만 : ^[0-9]*$
# 영문자만 : ^[a-zA-Z]*$
# 한글만 : ^[가-힣]*$
# 영어 & 숫자만 : ^[a-zA-Z0-9]*$
# E-Mail : ^[a-zA-Z0-9]+@[a-zA-Z0-9]+$
# 휴대폰 : ^01(?:0|1|[6-9]) - (?:\d{3}|\d{4}) - \d{4}$
# 일반전화 : ^\d{2,3} - \d{3,4} - \d{4}$
# 주민등록번호 : \d{6} \- [1-4]\d{6}
# IP 주소 : ([0-9]{1,3}) \. ([0-9]{1,3}) \. ([0-9]{1,3}) \. ([0-9]{1,3})

# POSIX 표준 정규 표현식의 문자 클래스
# [:alnum:] : 알파벳과 숫자
# [:alpha:] : 알파벳 대소문자
# [:blank:] : 탭(\t)
# [:cntrl:] : 제어 문자
# [:digit:] : 숫자
# [:xdigit:] : 16진수(hex)형 숫자, 즉 [0-9a-fA-F]
# [:upper:] : 알파벳 대문자
# [:lower:] : 알파벳 소문자
# [:space:] : 탭(\t), CR(\r), LF(\n)
# [:print:] : 출력 가능한 문자
# [:graph:] : 공백을 제외한 문자
# [:punct:] : 출력 가능한 특수 문자
# 정규 표현식에서 POSIX를 사용할 경우 "["와 "]"로 묶어줘야 한다.

# 4. 텍스트 마이닝을 수행할 데이터에서 정규 표현식 또는 gsub() 함수를 사용해서
# 불필요한 문자를 제거한다. => 전처리
# R에서 정규식 표현을 사용하려면 stringr 패키지를 설치하고 로드한다.
install.packages("stringr")
library(stringr)
txt <- readLines("./data/hiphop.txt")

# str_replace_all(변수, "찾을 문자열", "바꿀 문자열")
txt <- str_replace_all(txt, "\\W", "")
# gsub("찾을 문자열", "바꿀 문자열", 변수)
txt <- gsub("\\W", "", txt)
# [:punct:](출력 가능한(눈에 보이는) 특수 문자)
txt <- gsub("[[:punct:]]", "", txt)
# 출력 가능한 특수 문자와 숫자까지 제거하려면 아래와 같이 사용한다.
txt <- gsub("[[:punct:][:digit:]]", "", txt)
head(txt)

# ===============================================================================

# 5. extractNoun() 함수를 사용해서 명사를 추출한다. 망치면 여기부터 다시 실행한다.
noun <- extractNoun(txt)
class(noun) # list
# 결과가 list 타입이 나오면 unlist() 함수를 이용해서 vector로 변환한다.
noun <- unlist(noun)
class(noun) # character => 문자 vector
head(txt, 10)

# 6. table() 함수를 사용해 단어별 빈도표를 만든다.
wordCount <- table(noun)
class(wordCount) # table

# table 타입으로 생성된 단어별 빈도표를 as.data.frame() 함수를 사용해 데이터
# 프레임으로 변환한다.
df_wordCount <- as.data.frame(wordCount)
class(df_wordCount) # data.frame
head(df_wordCount, 10)

# 데이터프레임의 변수 이름은 워드 클라우드 옵션에 맞게 변경한다. => 안해도 됨!!!
df_wordCount <- rename(df_wordCount, word = noun, freq = Freq)

# 7. 데이터프레임에서 데이터를 정제한다.
# 숫자로만 구성된 단어와 단어에 포함된 모든 숫자가 제거된다.
# df_wordCount$word <- gsub("[[:digit:]]", "", df_wordCount$word)
# 단어가 숫자로만 구성된 경우 제거한다. => 선택적으로...
df_wordCount$word <- gsub("^[0-9]*$", "", df_wordCount$word)
df_wordCount$word <- gsub("  ", "", df_wordCount$word)

# 8. 워드 클라우드로 구성할 단어를 추출한다.
# 2음절 이상인 단어를 출현 빈도수의 내림차순으로 정렬해서 필요한 워드 클라우드로
# 구성할 단어를 추출한다.
# nchar() : 글자의 개수를 센다.
df_wordCount <- df_wordCount %>% 
  filter(nchar(word) >= 2) 
top200 <- df_wordCount %>% 
  arrange(desc(freq)) %>% 
  head(200)

# ===============================================================================

# 워드 클라우드
# 단어의 출현 빈도를 구름 모양으로 표한한 그래프로 단어의 출현 빈도에 따라 글자의
# 크기와 색상이 다르게 표현되기 때문에 어떤 단어가 얼마나 많이 사용되었는지
# 한 눈에 파악할 수 있다.

# 워드 클라우드 패키지를 설치하고 로드한다.
install.packages("wordcloud")
library(wordcloud)

# RColorBrewer 패키지는 R에 내장된 패키지 이므로 별도의 설치 없이 로드만 한다.
library(RColorBrewer)
# brewer.pal() 함수를 사용해서 단어에 표시할 색 목록을 만든다. => 선택적으로...
# 색상 팔레트에 대한 자세한 사항은 크롬에서 "팔레트 in r"로 검색하거나 아래의
# url을 참조한다.
# http://www.datamarket.kr/xe/index.php?mid=board_AGDR50&document_srl=203&listStyle=viewer
# brewer.pal(표현할 색상 개수, "팔레트 이름")
pal <- brewer.pal(10, "Dark2")

# 난수 고정하기 => 선택적으로...
# 워드 클라우드는 함수가 실행될 때 마다 난수를 발생시켜 매번 다른 모양의 워드
# 클라우드를 만들기 때문에 항상 동일한 모양의 워드 클라우드가 생성되기를 원한다면
# 워드 클라우드를 실행하기 전에 set.seed() 함수를 사용해서 난수를 고정시킨다.
set.seed(1)

# 워드 클라우드를 만든다.
wordcloud(
  words = top200$word, # 워드 클라우드로 표시할 단어 목록
  freq = top200$freq,  # 워드 클라우드에 표시할 단어의 출현 빈도수
  min.freq = 2,        # 워드 클라우드에 표시할 단어의 최소 개수
  max.words = 200,     # 워드 클라우드에 표시할 단어의 최대 개수
  rot.per = 0.1,       # 워드 클라우드에 표시되는 단어의 회전 비율
  random.order = F,    # 출현 빈도가 높은 단어를 중앙에 배치한다.
  scale = c(5, 0.5),   # 워드 클라우드에 표시되는 단어의 크기 범위
  colors = pal         # 단어에 표시할 색상 목록이 저장된 팔레트
)










