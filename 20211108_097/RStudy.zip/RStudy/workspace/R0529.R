library(kormaps2014)
library(ggplot2)
library(ggiraphExtra)
library(mapproj)
library(dplyr)

# kormaps2014 패키지는 지역별 결핵 환자수 정보 데이터(tbc)도 제공한다.
changeCode(tbc)
str(tbc)
# 결핵 환자수(NewPts)를 사용해서 단계 구분도를 작성할 수 있다.
tbc_kr <- tbc
changeCode(areacode)
str(areacode)
areacode_tbc <- areacode

tbc_kr$code <- as.character(tbc_kr$code)
class(tbc_kr$code)
areacode_tbc$code <- as.character(areacode_tbc$code)
class(areacode_tbc$code)
tbc_kr <- left_join(tbc_kr, changeCode(areacode_tbc), by = "code")

head(changeCode(tbc_kr))
ggChoropleth(data = tbc_kr, aes(fill = NewPts, map_id = code, tooltip = name.y),
             map = kormap1, interactive = T)

# ===============================================================================

# interactive 시계열 그래프
# dygraphs 패키지를 사용해 interactive 시계열 그래프를 만들려면 데이터가 시간
# 순서의 속성을 가지고 있는 xts 데이터 타입으로 되어있어야 하고 xts() 함수를 사용해
# 그래프로 표시하려는 데이터의 타입을 변경시켜 추출해야 한다.
install.packages("dygraphs")
library(dygraphs)
# dygraphs 패키지가 설치될 때 같이 설치되므로 xts 패키지는 로드만 시키면 된다.
library(xts)

# xts(interactive 시계열 그래프로 표시할 데이터, order.by = 시계열 데이터)
eco <- xts(economics$unemploy, order.by = economics$date)
# dygraph() 함수에 xts 타입의 데이터를 지정해서 그래프를 만든다.
dygraph(eco)

# '%>%'를 이용해서 dyRangeSelector() 함수를 실행하면 그래프 하단에 시계열 범위를
# 지정할 수 있는 기능이 추가된다.
dygraph(eco) %>% dyRangeSelector()

# interactive 시계열 그래프에 여러 값 표시하기
# 실업자수(unemploy)와 저축율(psavert) interactive 시계열로 표시하기 위해 각각의
# 값을 기억하는 변수를 xts() 함수를 이용해 만든다.

# xts() 함수는 interactive 시계열 그래프로 작성할 데이터를 2개 이상을 한번에
# 추출할 수 없기 때문에 각각 추출해서 나중에 합쳐서 처리해야 한다.
# 시계열 그래프로 표시할 데이터의 단위가 일치하지 않으면 맞춰줘야 한다.
economics_unemploy <- xts(economics$unemploy / 1000, order.by = economics$date)
head(economics_unemploy)
class(economics_unemploy)
economics_psavert <- xts(economics$psavert, order.by = economics$date)
head(economics_psavert)

# 행열 형태의 데이터를 가지는(열이름, 변수 이름이 없는) 데이터를 합친다.
# cbind() => dplyr 패키지의 left_join() 함수와 같은 기능이 실행된다.
# rbind() => dplyr 패키지의 bind_rows() 함수와 같은 기능이 실행된다.
# cbind() 함수를 사용해서 economics_unemploy와 economics_psavert를 합친다.
eco2 <- cbind(economics_unemploy, economics_psavert)
head(eco2)

# colnames() => dplyr 패키지의 rename() 함수와 같은 기능이 실행된다.
colnames(eco2) <- c("unemploy", "psavert")
head(eco2)

dygraph(eco2) %>% dyRangeSelector()

# ===============================================================================

# 정적 웹 스크레이핑(크롤링)
# 네이버 영화 사이트 데이터 중에서 영화 제목, 평점, 리뷰만 추출해서 csv 파일에
# 저장한다.

# 타겟 사이트 : https://movie.naver.com/movie/point/af/list.nhn?&page=1
# 제목 => class="movie color_b"
# 평점 => td.title > div > em
# 리뷰 => class="title" => 가공작업

# 1. 웹 스크레이핑에 사용할 패키지를 설치하고 로드한다.
install.packages("rvest")
library(rvest)

# 2. 스크레이핑 할 웸 사이트 주소를 지정한다.
url <- "https://movie.naver.com/movie/point/af/list.nhn?&page=1"

# 3. xml2 패키지의 read_html() 함수로 지정한 웹 사이트 전체 내용을 읽는다. => 수집
# 읽어오다 한글 문제로 인해서 에러가 발생되거나 한글이 깨지면 encoding = "CP949"
# 옵션을 지정해서 한글이 깨지지 않도록 한다.
content <- read_html(url, encoding = "CP949")

# 4. rvest 패키지의 html_nodes() 함수로 읽어온 html 문서에서 필요한 데이터를 
# 읽는다.
# class 속성이 지정된 데이터를 읽어야 하므로 앞에 반드시 "."을 찍어야 한다.
nodes <- html_nodes(content, ".movie")

# 5. rvest 패키지의 html_text() 함수로 trim = T 옵션을 지정해 불필요한 빈 칸을
# 제거하고 텍스트만 읽어온다.
movie <- html_text(nodes, trim = T)

# 6. 평점은 td.title > div > em(td의 자식 div의 자식 em)을 사용해서 읽어들인다.
nodes <- html_nodes(content, "td.title > div > em")
point <- html_text(nodes, trim = T)

# 7. 리뷰는 네이버 영화 사이트가 리뉴얼 되면서 읽어들일 리뷰에 지정되었던 css
# 선택자가 없어져서 아래와 같이 읽어서 리뷰만 뽑아낸다. => 정제
nodes <- html_nodes(content, ".title")
title <- html_text(nodes, trim = T)
# 읽어들인 내용에서 제어문자(\t, \n)를 제거한다.
title <- gsub("[[:cntrl:]]", "", title)
# strsplit() 함수를 사용해서 영화제목, 평점, 리뷰를 분리시킨다. => 분리한 결과는
# list 타입이다. => unlist() 함수를 사용해서 vector로 변환시켜야 한다.
# 중[0-9]{1,2} => "중" 뒤에 숫자가 1글자 이상 2글자 이하
title <- strsplit(title, "중[0-9]{1,2}")
class(title)
# strsplit() 함수 실행 결과를 unlist() 함수를 사용해서 벡터로 바꾼다.
title <- unlist(title)
title <- gsub("신고", "", title)
# 리뷰를 기억할 빈 변수를 선언한다.
review = NULL # 데이터를 기억하지 않는 빈 변수는 NULL을 대입해서 선언하면 된다.
for(i in seq(2, 20, by = 2)) {
  # print(i)
  review = c(review, title[i])
}

# cbind() 함수를 사용해서 제목, 평점, 리뷰를 합친다.
page <- cbind(movie, point)
page <- cbind(page, review)
class(page) # matrix

# 데이터 처리를 위해서 데이터프레임 형태로 변환시킨다.
page <- as.data.frame(page)
class(page) # data.frame

print(page)
# 웹 스크레이핑 된 데이터를 csv 파일로 저장시킨다.
write.csv(page, "./data/movie_review.csv")

# ===============================================================================

# for를 이용하는 반복처리

# for(변수명 in 반복횟수) {
#     반복할 문장
#     ...
# }

# i가 1부터 5까지 1씩 증가하면서 반복된다.
for(i in 1:5) {
  print(i)
}

# i가 5부터 1까지 1씩 감소하면서 반복된다.
for(i in 5:1) {
  print(i)
}

# i가 1, 3, 5, 7, 9로 변경되며 반복한다.
for(i in c(1, 3, 5, 7, 9)) {
  print(i)
}

# seq(초기치, 최종치, by = 증가치)
for(i in seq(1, 10, by = 2)) {
  print(i)
}
# 증가치가 1일 경우 by 옵션을 생략할 수 있다.
for(i in seq(1, 10)) {
  print(i)
}
# by를 생략하고 증가치만 써도 된다.
for(i in seq(1, 10, 2)) {
  print(i)
}

# i가 10 부터 1까지 2씩 감소하며 반복한다.
for(i in seq(10, 1, -2)) {
  print(i)
}

# ===============================================================================

# 반복문을 사용해서 여러 페이지 읽어오기

library(rvest)
# 웹 스크레이핑 할 대 변경되지 않는 주소 부분을 저장해 둔다.
site <- "https://movie.naver.com/movie/point/af/list.nhn?&page="

# 여러 페이지에서 읽어온 리뷰를 합칠 기억 장소를 선언하고 NULL로 초기화시킨다.
movie_review = NULL

# 읽어올 페이지 분량 만큼 반복하며 리뷰를 읽는다.
for (i in 1:2) {
  url <- paste(site, i, sep = "")
  
  content <- read_html(url, encoding = "CP949")

  nodes <- html_nodes(content, ".movie")
  movie <- html_text(nodes)
  print(movie)
  
  nodes <- html_nodes(content, "td.title > div > em")
  point <- html_text(nodes)
  print(point)
}


# paste() 함수로 변경되지 않는 주소와 변경되는 주소를 이어붙여서 읽어들일 페이지의
# 주소를 만든다.
# print(paste(site, i, sep = ""))

# print(url)
# 한 페이지를 읽어들인 후 다음 페이지가 로딩되는 시간동안 잠깐 스크레이핑을
# 멈춰주는 동작이 필요하다. => 페이지가 전환 될 때 실행한다.
#Sys.sleep(1) # 시간은 초 단위로 지정한다.

# 영화제목
# 평점
# 리뷰
nodes <- html_nodes(content, ".title")
title <- html_text(nodes)
title <- gsub("[[:cntrl:]]", "", title)
title <- strsplit(title, "중[0-9]{1,2}")
title <- unlist(title)
title <- gsub("신고", "", title)
review = NULL
for(j in seq(2, 20, by = 2)) {
  review = c(review, title[j])
}  

# cbind() 함수를 사용해서 제목, 평점, 리뷰를 합친다.
#page <- cbind(movie, point)
#page <- cbind(page, review)

# 여러 페이지의 리뷰 결과를 기억할 movie_review에 rbind() 함수로 한 페이지씩
# 스크레이핑 한 데이터를 합쳐준다.
#movie_review <- rbind(movie_review, page)

class(movie_review)
# 최종 스크레이핑된 데이터는 matrix 타입이기 때문에 데이터 처리를 위해서 데이터
# 프레임 타입으로 변환시킨다.
movie_review <- as.data.frame(movie_review)
class(movie_review)

# 웹 스크레이핑된 데이터를 csv 파일로 저장한다.
write.csv(page, "./data/movie_review.csv")






