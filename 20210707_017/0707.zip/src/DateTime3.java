import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateTime3 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
//		System.out.print("년, 월, 일: ");
//		int year = scanner.nextInt() - 1900;
//		int month = scanner.nextInt() - 1;
//		int day = scanner.nextInt();
//		
//		Date date = new Date(year, month, day);
//		System.out.println(date);
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd(E)");
//		System.out.println(sdf.format(date));

//		주민등록번호를 입력받아 생일을 날짜 데이터로 만들기
		System.out.print("주민등록번호: ");
		String junumNo = scanner.nextLine().trim();
		
//		System.out.println(junumNo.substring(0, 2));
//		System.out.println(junumNo.substring(2, 4));
//		System.out.println(junumNo.substring(4, 6));
		
		int year = (junumNo.substring(0, 2).charAt(0) - 48) * 10 + (junumNo.substring(0, 2).charAt(1) - '0');
//		System.out.println(year);
		int month = (junumNo.substring(2, 4).charAt(0) - 48) * 10 + (junumNo.substring(2, 4).charAt(1) - '0');
//		System.out.println(month);
		int day = (junumNo.substring(4, 6).charAt(0) - 48) * 10 + (junumNo.substring(4, 6).charAt(1) - '0');
//		System.out.println(day);
		
		if (junumNo.charAt(6) > '2') {
			year += 100;
		}
		
		Date date = new Date(year, month - 1, day);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd(E)");
		System.out.println(sdf.format(date));
		
	}

}


























