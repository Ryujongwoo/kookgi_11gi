package com.koreait.springDI4_xml_interface;

public interface Pencil {

	public abstract void use();
	
}
