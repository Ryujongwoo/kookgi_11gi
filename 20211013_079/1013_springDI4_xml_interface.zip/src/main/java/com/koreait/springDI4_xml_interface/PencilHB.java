package com.koreait.springDI4_xml_interface;

public class PencilHB implements Pencil {

	@Override
	public void use() {
		
		System.out.println("HB 연필로 글씨를 씁니다.");

	}

}
