package com.koreait.springDI4_xml_interface;

public class Pencil4B implements Pencil {

	@Override
	public void use() {
		
		System.out.println("4B 연필로 그림을 그립니다.");

	}

}
