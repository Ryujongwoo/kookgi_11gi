$(() => {
	$('#shuffle').cycle({
	    fx:     'shuffle',
	    easing: 'easeOutBack',
	    delay:  -4000
	});
	
	$('#zoom').cycle({
	    fx:    'zoom',
		sync:  false,
	    delay: -2000
	});
});
