function singleArr() {
//	배열 선언 방법
	var arrayObj = new Array();		// 크기가 0인 빈 배열 객체를 선언한다.
	console.log(arrayObj);
	console.log(typeof arrayObj);
	console.log(arrayObj.length);
	console.log('================================================');
	
	var arrayObj2 = new Array(5);	// 크기가 5인 빈 배열 객체를 선언한다.
	console.log(arrayObj2);
	console.log(typeof arrayObj2);
	console.log(arrayObj2.length);
	console.log('================================================');
	
//	크기가 5인 배열 객체를 선언하고 인수로 지정한 데이터로 초기화한다.
	var arrayObj3 = new Array(1, 2, 3, 4, 5);
	console.log(arrayObj3);
	console.log(typeof arrayObj3);
	console.log(arrayObj3.length);
	console.log('================================================');
	
//	리터럴 이용, []에 지정된 초기치의 개수만큼 배열 객체를 선언하고 초기치로 초기화한다.
	var arrayObj4 = ['value1', 'value1', 3, 4];
	console.log(arrayObj4);
	console.log(typeof arrayObj4);
	console.log(arrayObj4.length);
	console.log('================================================');
}

function multiArr() {
	var arrRow = 4;		// 행의 개수
	var arrCol = 3;		// 열의 개수
	
//	행을 먼저 만들고 행의 개수만큼 반복하며 열을 만든다.
	var arr = new Array(arrRow);		// 행을 만든다.
	for (var i = 0; i < arrRow; i++) {
		arr[i] = new Array(arrCol);		// 열을 만든다.
	}
	
	arr[0][0] = 'apple';
	arr[0][1] = 'banana';
	arr[0][2] = 'melon';
	
	arr[1][0] = 100;
	arr[1][1] = 200;
	arr[1][2] = 300;
	
	arr[2][0] = true;
	arr[2][1] = 999;
	arr[2][2] = '홍길동';
	
//	배열에 배열을 저장시킬 수 있다.
	arr[3][0] = ['임꺽정', '바보'];
	arr[3][1] = ['장길산', '천재'];
	arr[3][2] = ['코로나는', '무섭다'];
	
	console.log(arr);
	console.log(arr[0]);
}

function joinTest() {
	var fruit = ['apple', 'banana', 'melon', 'mango'];
	var arr = ['111', '222', '333', '444'];
	
//	배열끼리 덧셈 연산을 실행하면 배열을 합쳐서 ','로 구분된 문자열을 만든다.
	var add = fruit + arr;
	console.log(add);
	console.log(typeof add);
	
//	join() 함수는 배열 요소의 데이터 사이에 인수로 지정한 문자열을 삽입해서 문자열로 만든다.
	var result = fruit.join('|');
	console.log(result);
	console.log(typeof result);
	
//	concat() 함수는 2개 이상의 배열을 합쳐서 배열로 만든다.
	var result2 = fruit.concat(arr);
	console.log(result2);
	console.log(typeof result2);
}























