function formCheck(obj) {
	if (!obj.category.value || obj.category.value.trim().length == 0) {
		alert('카테고리는 반드시 입력해야 합니다.');
		obj.category.value = '';
		obj.category.focus();
		return false;
	}
	return true;
}

// $(document).ready(function() {
// $(function() {
$(() => {
	
//	메인 카테고리에 아무것도 입력되지 않았는가 검사한다.
//	메인 카테고리 입력은 1개만 있기 때문에 id를 지정해서 처리한다.
//	$('#form').submit(): form이라는 id가 지정된 form에서 submit 버튼이 클릭되면 submit() 메소드의
//	인수로 지정된 함수가 실행된다.
//	이 때, 익명 함수의 인수(event)로 실행되는 이벤트가 넘어온다.
	$('#form').submit(function(event) {
		alert('submit');
	});
	
});

















