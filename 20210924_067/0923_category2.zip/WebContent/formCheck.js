function formCheck(obj) {
	if (!obj.category.value || obj.category.value.trim().length == 0) {
		alert('카테고리는 반드시 입력해야 합니다.');
		obj.category.value = '';
		obj.category.focus();
		return false;
	}
	return true;
}

// $(document).ready(function() {
// $(function() {
$(() => {
	
//	메인 카테고리에 아무것도 입력되지 않았는가 검사한다.
//	메인 카테고리 입력은 1개만 있기 때문에 id를 지정해서 처리한다.
//	$('#form').submit(): form이라는 id가 지정된 form에서 submit 버튼이 클릭되면 submit() 메소드의
//	인수로 지정된 함수가 실행된다.
//	이 때, 익명 함수의 인수(event)로 실행되는 이벤트가 넘어온다.
	$('#form').submit(function(event) {
//		$('#category').val(): category라는 id 속성이 지정된 텍스트 상자에 입력된 값을 얻어온다.
//		$.trim(): 인수로 지정된 문자열 앞, 뒤의 불필요한 빈 칸을 제거한다.
		var category = $.trim($('#category').val()).length; // 메인 카테고리 텍스트 박스에 입력한 글자수
//		console.log(event);
		if (category == 0) {
			alert('메인 카테고리는 반드시 입력해야 합니다.');
//			유효성 검사를 실행했는데 규칙에 위배되므로 action 페이지로 넘겨주는 기본(default) 동작을 중지시킨다.
//			preventDefault(): event로 넘어온 기본 이벤트 실행을 중지한다.
			event.preventDefault();
//			$('#category').val(''); // category라는 id 속성이 지정된 텍스트 박스의 내용을 지운다.
			$('#form')[0].reset();	// form이라는 id 속성이 지정된 폼에서 reset을 실행한다. 반드시 인덱스를 지정해야 한다.
			$('#category').focus(); // category라는 id 속성이 지정된 텍스트 박스로 포커스를 옮겨준다.
		}
	});
	
//	서브 카테고리에 아무것도 입력되지 않았는가 검사한다.
//	서브 카테고리 입력은 여러개가 있기 때문에 class를 지정해서 처리한다.
//	서브 카테고리를 입력하는 폼의 개수만큼 반복하며 모든 서브 카테고리 form에 이름이 다른 class 속성을 지정한다.
//	$('.sub_form').each(function(index, item) { })
//	sub_form이라는 class 속성이 지정된 form의 개수만큼 each() 메소드의 인수로 지정한 익명 함수를 반복해서 실행한다.
//	index: sub_form이라는 class 속성이 지정된 객체의 일련번호가 저장된다.
//	item: sub_form이라는 class 속성이 지정된 객체가 저장된다.
	$('.sub_form').each(function(index, item) {
//		console.log('index: ' + index + ', item: ' + item);
//		addClass() 메소드로 each() 메소드를 통해서 반복되는 객체(서브 카테고리 폼)에 class 속성을 추가한다.
		$(item).addClass('sub_form' + index);
	});
	
//	서브 카테고리를 입력하는 텍스트 박스의 개수만큼 반복하며 모든 서브 카테고리를 입력하는 텍스트 박스에 이름이 다른 
//	class 속성을 지정한다.
	$('.sub_category').each(function(index, item) {
		$(item).addClass('sub_category' + index);
	});
	
	$('.sub_form').each(function(index, item) {
		$('.sub_form' + index).submit(function(e) {
			var sub_category = $.trim($('.sub_category' + index).val()).length; // 서브 카테고리 텍스트 박스에 입력한 글자수
			if (sub_category == 0) {
				alert('서브 카테고리는 반드시 입력해야 합니다.');
				e.preventDefault();
				$('.sub_form' + index)[0].reset();
				$('.sub_category' + index).focus();
			}
		});
	});
});

















