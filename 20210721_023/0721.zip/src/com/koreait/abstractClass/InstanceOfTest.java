package com.koreait.abstractClass;

//	다형성(polymorphism)이란 하나의 메소드가 서로 다른 클래스에서 다양하게 실행되는 것을 말한다.
//	다형성을 구현하기 위해서는 다형성을 구현할 메소드가 포함된 모든 클래스가 같은 부모 클래스 또는 인터페이스를 가져야 한다.
//	부모 클래스 또는 인터페이스와 자식 클래스에 같은 이름의 메소드가 있어야 하고 자식 클래스는 이 메소드를 반드시 Override 시켜서
//	사용해야 한다.
//	부모 클래스 타입의 객체에 자식 클래스 타입의 객체를 대입시켜 다형성이 구현된 메소드를 실행한다.
class Animal {
	
	public void move() {
		System.out.println("동물이 움직입니다.");
	}
	
	public void eating() {
		
	}
	
}

class Human extends Animal {
	
	public void move() {
		System.out.println("사람이 두 발로 걷습니다.");
	}
	
	public void readBooks() {
		System.out.println("사람이 책을 읽습니다.");
	}
	
}

class Tiger extends Animal {
	
	public void move() {
		System.out.println("호랑이는 네 발로 걷습니다.");
	}
	
	public void hunting() {
		System.out.println("호랑이가 사냥을 합니다.");
	}
	
}

class Eagle extends Animal {
	
	public void move() {
		System.out.println("독수리가 하늘을 날아갑니다.");
	}
	
	public void flying() {
		System.out.println("독수리가 날개를 쫘~~~~ㄱ 펴고 멀리 날아갑니다.");
	}
	
}

public class InstanceOfTest {

	public static void main(String[] args) {
		
		Animal hAnimal = new Human();
		Animal tAnimal = new Tiger();
		Animal eAnimal = new Eagle();

		InstanceOfTest test = new InstanceOfTest();
		test.moveAnimal(hAnimal);
		test.moveAnimal(tAnimal);
		test.moveAnimal(eAnimal);
		
	}

	public void moveAnimal(Animal animal) {
		animal.move();
	}
	
}














