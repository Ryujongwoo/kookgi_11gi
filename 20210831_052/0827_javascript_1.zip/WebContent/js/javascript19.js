function openWin() {
//	window.open();		// 아무 내용이 없는 빈 윈도우가 실행된다.
//	window.open(url, title, option);
	var url = './javascript20.jsp';		// 새로 띄울 창에 표시할 페이지 이름
	var title = '아이디 중복 검사';		// 윈도우 이름
	var option = 'top=50px, left=100px, width=500px, height=600px';		// 윈도우 옵션
	window.open(url, title, option);
}















