package com.koreait.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.koreait.springWEB5_DBCP_board.Constant;
import com.koreait.vo.MvcboardVO;

public class MvcboardDAO {

	private JdbcTemplate template;
	
	public MvcboardDAO() {
		this.template = Constant.template;
	}
	
//	메인글 저장
	public void insert(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 insert() 메소드");
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " +
				"values (mvcboard_idx_seq.nextval, ?, ?, ?, mvcboard_idx_seq.currval, 0, 0)";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());
				ps.setString(2, mvcboardVO.getSubject());
				ps.setString(3, mvcboardVO.getContent());
			}
		});
	}

//	전체 글 개수
	public int selectCount() {
		System.out.println("MvcboardDAO의 selectCount() 메소드");
		String sql = "select count(*) from mvcboard";
		return template.queryForInt(sql);
	}

//	1페이지 분량의 글
	public ArrayList<MvcboardVO> selectList(HashMap<String, Integer> hmap) {
		System.out.println("MvcboardDAO의 selectList() 메소드");
		String sql = "select * from (" + 
			     "    select rownum rnum, AA.* from (" +
			     "        select * from mvcboard order by gup desc, seq asc" +
			     "    ) AA where rownum <= " + hmap.get("endNo") + 
			     ") where rnum >= " + hmap.get("startNo");
		return (ArrayList<MvcboardVO>) template.query(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

//	조회수 증가
	public void increment(final int idx) {
		System.out.println("MvcboardDAO의 increment() 메소드");
		String sql = "update mvcboard set hit = hit + 1 where idx = " + idx;
		template.update(sql);
	}

//	글 1건
	public MvcboardVO selectByIdx(int idx) {
		System.out.println("MvcboardDAO의 selectByIdx() 메소드");
		String sql = "select * from mvcboard where idx = " + idx;
		return template.queryForObject(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

//	글 수정 - 1
	public void update(final int idx, final String subject, final String content) {
		System.out.println("MvcboardDAO의 update(int idx, String subject, String content) 메소드");
		String sql = "update mvcboard set subject = '" + subject + "', content = '" + content + 
				"' where idx = " + idx;
		template.update(sql);
	}

//	글 수정 - 2
	public void update(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 update(MvcboardVO mvcboardVO) 메소드");
		String sql = "update mvcboard set subject = '" + mvcboardVO.getSubject() + "', content = '" + 
				mvcboardVO.getContent() + "' where idx = " + mvcboardVO.getIdx();
		template.update(sql);

	}

//	글 삭제
	public void delete(final int idx) {
		System.out.println("MvcboardDAO의 delete() 메소드");
		String sql = "delete from mvcboard where idx = " + idx;
		template.update(sql);
	}

//	조건에 만족하는 seq 1증가
	public void replyIncrement(final HashMap<String, Integer> hmap) {
		System.out.println("MvcboardDAO의 replyIncrement() 메소드");
		String sql = "update mvcboard set seq = seq + 1 where gup = ? and seq >= ?";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, hmap.get("gup"));
				ps.setInt(2, hmap.get("seq"));
			}
		});
	}

	public void replyInsert(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 replyInsert() 메소드");
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " + 
				"values (mvcboard_idx_seq.nextval, ?, ?, ?, ?, ?, ?)";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());
				ps.setString(2, mvcboardVO.getSubject());
				ps.setString(3, mvcboardVO.getContent());
				ps.setInt(4, mvcboardVO.getGup());
				ps.setInt(5, mvcboardVO.getLev());
				ps.setInt(6, mvcboardVO.getSeq());
			}
		});
	}

}



















