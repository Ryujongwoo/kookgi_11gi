-- 시퀀스 만들기
CREATE SEQUENCE category_idx_seq;

-- 시퀀스 다시 1부터 증가
DELETE FROM category;
DROP SEQUENCE category_idx_seq;
CREATE SEQUENCE category_idx_seq;

SELECT * FROM CATEGORY;

insert into category (idx, category, gup, lev, seq) 
		values (category_idx_seq.nextval, '가구', category_idx_seq.currval, 0, 0);
		