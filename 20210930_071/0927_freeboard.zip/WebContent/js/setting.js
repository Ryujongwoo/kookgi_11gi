function setting(idx, mode, title, name, content) {
	var frm = document.commentForm;		// contentView.jsp의 댓글 폼
	frm.idx.value = idx;				// 수정 또는 삭제할 댓글 번호를 넣어준다. 댓글 입력시에는 0으로 처리한다.
	frm.mode.value = mode;				// 댓글 작업 모드를 넣어준다. 1 => 저장, 2 => 수정, 3 => 삭제
	frm.commentBtn.value = title;		// submit 버튼에 표시될 텍스트를 넣어준다.
	frm.name.value = name;				// 댓글 작성자 이름을 댓글 폼의 name text 객체에 넣어준다.
	
//	co.content를 넘겨받으면 javascript는 이스케이프 시퀀스가 포함된 데이터를 인수로 받을 수 없기 때문에 정상적으로
//	작동되지 않는다.
//	이스케이프 시퀀스가 포함된 문자열을 인수로 넘겨주려면 일반적으로 자주 사용하지 않는 문자열이나 줄바꿈에 사용하는
//	<br/> 태그로 이스케이프 시퀀스를 치환시켜 javascript 함수의 인수로 데이터를 전달해야 한다.
//	이스케이프 시퀀스가 치환되서 넘어온 데이터를 textarea에 넣어주려면 다시 이스케이프 시퀀스로 치환해서 넣어야 한다.

//	java나 jap의 replace 메소드는 모든 내용을 일괄적으로 치환하지만 javascript의 replace 함수는 맨 처음의 1개만 치환한다.
//	인수로 넘어온 데이터에 더 이상 <br/>이 나타나지 않을 때 까지 반복하며 '\r\n'으로 치환시켜야 한다.
	while (content.indexOf('<br/>') != -1) {
		content = content.replace('<br/>', '\r\n');
	}
	frm.content.value = content;		// 댓글 내용을 댓글 폼의 textarea 객체에 넣어준다.
}