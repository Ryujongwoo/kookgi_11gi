package com.koreait.springProperties1_Environment;

import java.io.IOException;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.io.support.ResourcePropertySource;

public class MainClass {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext ctx = new GenericXmlApplicationContext();
		ConfigurableEnvironment env = ctx.getEnvironment();
		MutablePropertySources mutablePropertySources = env.getPropertySources();
		
		try {
			mutablePropertySources.addLast(new ResourcePropertySource("classpath:admin.properties"));
			System.out.println("admin.id: " + env.getProperty("admin.id"));
			System.out.println("admin.pw: " + env.getProperty("admin.pw"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("properties 파일의 내용을 읽어온다.");
		System.out.println("============================================");
		
		GenericXmlApplicationContext gCtx = (GenericXmlApplicationContext) ctx;
		gCtx.load("classpath:applicationCTX.xml");
		gCtx.refresh();
		System.out.println("============================================");
		
		AdminConnection adminConnection = gCtx.getBean("adminConnection", AdminConnection.class);
		System.out.println("adminId: " + adminConnection.getAdminId());
		System.out.println("adminPw: " + adminConnection.getAdminPw());
		System.out.println("============================================");
		
		/*
//		AdminConnection 클래스의 bean이 생성된 후 환경 설정 정보에 저장된 admin.properties 파일의 정보를
//		넘겨준다.
		adminConnection.setAdminId(env.getProperty("admin.id"));
		adminConnection.setAdminPw(env.getProperty("admin.pw"));
		
		System.out.println("adminId: " + adminConnection.getAdminId());
		System.out.println("adminPw: " + adminConnection.getAdminPw());
		*/
		
		gCtx.close();
		
	}
	
}

















