package com.koreait.service;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.koreait.dao.MvcboardDAO;
import com.koreait.vo.MvcboardVO;

public class InsertService implements MvcboardService {

	@Override
	public void execute(MvcboardVO mvcboardVO) {
		System.out.println("InsertService의 execute() 메소드 - VO 사용");
//		System.out.println(mvcboardVO);
		
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		MvcboardDAO mvcboardDAO = ctx.getBean("mvcboardDAO", MvcboardDAO.class);
//		메인글을 테이블에 저장하는 메소드를 호출한다.
		mvcboardDAO.insert(mvcboardVO);
	}

}
