package com.koreait.dao;

import com.koreait.vo.MvcboardVO;

public class MvcboardDAO {

	public void insert(MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 insert() 메소드");
		System.out.println(mvcboardVO);
	}

}
