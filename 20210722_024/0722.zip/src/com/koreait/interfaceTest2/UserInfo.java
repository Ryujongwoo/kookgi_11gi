package com.koreait.interfaceTest2;

public class UserInfo {

	private String userId;
	private String passwd;
	private String userName;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Override
	public String toString() {
		return "UserInfo [userId=" + userId + ", passwd=" + passwd + ", userName=" + userName + "]";
	}
	
}
