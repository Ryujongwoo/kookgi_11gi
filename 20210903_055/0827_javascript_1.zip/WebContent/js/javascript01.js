// 'use strict'를 사용하면 선언하지 않은 변수를 사용하면 에러가 발생된다. => ECMAScript5에서 추가
'use strict';

console.log("Hello World");

// a = 0;	// 에러 발생
var a = 0;
// let a = 0;
// const a = 0;
console.log("a: " + a);

