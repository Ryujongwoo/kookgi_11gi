function locationTest() {
//	location.href='https://www.naver.com';
	
//	location 객체의 assign() 함수는 location.href와 같은 기능이 실행된다.
//	location.assign('https://www.naver.com');

//	location 객체의 replace() 함수는 기본적으로 location.href, assign()와 같은 기능이 
//	실행되지만 location.href, assign()를 사용했을 때는 돌아가기 버튼을 사용할 수 있는
//	반면에 replace()를 사용하면 돌아가기 버튼을 사용할 수 없다.
	location.replace('https://www.naver.com');
}

