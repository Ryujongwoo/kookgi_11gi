package com.koreait.generic2;

public abstract class Material {

	abstract void doPrinting();
	
}
