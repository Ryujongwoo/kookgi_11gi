package com.koreait.generic;

public class Plastic {

	@Override
	public String toString() {
		return "재료는 Plastic 입니다.";
	}
	
}
