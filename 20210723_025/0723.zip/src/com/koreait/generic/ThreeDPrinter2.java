package com.koreait.generic;

//	Plastic을 재료로 사용하는 3D 프린터
public class ThreeDPrinter2 {

	private Plastic material;

	public Plastic getMaterial() {
		return material;
	}
	public void setMaterial(Plastic material) {
		this.material = material;
	}
	
}
