package com.koreait.generic;

public class Water {

	@Override
	public String toString() {
		return "재료는 Water 입니다.";
	}
	
}
