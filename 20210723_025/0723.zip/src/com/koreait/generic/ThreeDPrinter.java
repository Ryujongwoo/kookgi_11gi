package com.koreait.generic;

//	Powder와 Plastic을 재료로 사용하는 3D 프린터 => Object 사용
public class ThreeDPrinter {

	private Object material;

	public Object getMaterial() {
		return material;
	}
	public void setMaterial(Object material) {
		this.material = material;
	}
	
}
