package com.koreait.generic;

public class Powder {

	@Override
	public String toString() {
		return "재료는 Powder 입니다.";
	}
	
}
