package com.koreait.generic;

//	Powder를 재료로 사용하는 3D 프린터
public class ThreeDPrinter1 {

	private Powder material;

	public Powder getMaterial() {
		return material;
	}
	public void setMaterial(Powder material) {
		this.material = material;
	}
	
}
