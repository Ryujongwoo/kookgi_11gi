select * from memolist;

select * from memolist order by idx desc;

delete from memolist;
alter table memolist auto_increment = 1;

