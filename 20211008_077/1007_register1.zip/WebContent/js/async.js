console.log('sync/async');

function sync() {
	var start = Date.now();
//	console.log(start);
	for (var i = 0; i < 1000000000; i++) {
		
	}
	var end = Date.now();
	console.log(end - start + 'ms');
}
console.log('동기방식');
console.log('작업 시작');
sync();
console.log('다음 작업');
console.log('==============================');

function async() {
	setTimeout(function() {
		var start = Date.now();
		for (var i = 0; i < 1000000000; i++) {
			
		}
		var end = Date.now();
		console.log(end - start + 'ms');
	}, 1000);
}
console.log('비동기방식');
console.log('작업 시작');
async();
console.log('다음 작업');
console.log('==============================');
