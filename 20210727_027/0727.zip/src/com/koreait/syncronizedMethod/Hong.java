package com.koreait.syncronizedMethod;

public class Hong extends Thread {

	@Override
	public void run() {
		System.out.println("start minus");
		SyncMain.myBank.minusMoney(10000);
		System.out.println("minusMoney(10000): " + SyncMain.myBank.getMoney());
	}

}
