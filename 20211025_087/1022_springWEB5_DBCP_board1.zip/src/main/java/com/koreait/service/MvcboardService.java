package com.koreait.service;

import org.springframework.ui.Model;

import com.koreait.vo.MvcboardVO;

public interface MvcboardService {

	void execute(MvcboardVO mvcboardVO);
	void execute(Model model);
	
}
