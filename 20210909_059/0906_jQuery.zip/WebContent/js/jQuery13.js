$(() => {
	$('.delete').click(function() {
//		$(this).parent().slideUp('slow');
		$(this).parent().slideUp('slow', 'easeInOutBounce');
	});
	
	$('#view').click(function() {
		$('.pane').slideDown('slow');
//		$('.pane').show('slow');
//		$('.pane').fadeIn('slow');
//		$('.pane').css('display', 'block');
	});
});