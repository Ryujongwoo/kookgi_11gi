DELETE FROM FREEBOARD;
DROP SEQUENCE freeboard_idx_seq;
CREATE SEQUENCE freeboard_idx_seq;
SELECT * FROM freeboard;



