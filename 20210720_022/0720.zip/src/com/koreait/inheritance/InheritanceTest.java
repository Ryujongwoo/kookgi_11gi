package com.koreait.inheritance;

public class InheritanceTest {

	public static void main(String[] args) {
		
		Parent parent = new Parent();
		System.out.println(parent);
		Parent parent2 = new Parent("홍길동", true);
		System.out.println(parent2);
		System.out.println("=======================");
		
		System.out.println(parent2.name);
		Child child = new Child();
		System.out.println(child.name);

	}

}
